USE db_aacf96_adne2024
GO

---------------------------------------* CREACI�N DE COMBOBOX *---------------------------------------

--Se crea la tabla de Desempe�o
CREATE TABLE Desempeno(
--		CAMPO				TIPO DE DATO			RESTRICCIONES
		desempenoId			INT						IDENTITY (1,1) PRIMARY KEY,
		desempeno			VARCHAR(60)				NOT NULL
)
GO

--Insertamos los roles que existen en ADNE
INSERT INTO Desempeno VALUES
('Administrador'),
('Empleado')
GO

SELECT * FROM Desempeno
GO

--Se crea la tabla de Especialidad
CREATE TABLE Especialidad(

--		CAMPO				TIPO DE DATO			RESTRICCIONES
		especialidadId		INT						IDENTITY (1,1) PRIMARY KEY,
		nombreEspecialidad	VARCHAR(50)				NOT NULL
)
GO

INSERT INTO Especialidad VALUES
('Profesional'),
('Psic�logo'),
('Terapeuta'),
('Educador')
GO

SELECT * FROM Especialidad
GO

--Se crea la tabla de Genero
CREATE TABLE Genero(

--		CAMPO				TIPO DE DATO			RESTRICCIONES
		generoId			INT						IDENTITY (1,1) PRIMARY KEY,
		genero				VARCHAR(45)				NOT NULL
)
GO

INSERT INTO Genero VALUES
('Masculino'),
('Femenino'),
('LGBT Comunity'),
('Otro')
GO

SELECT * FROM Genero
GO

--Se crea la tabla de Relacion Encargado (Relaci�n familiar que tiene con el paciente actual)
CREATE TABLE RelacionEncargado(

--		CAMPO				TIPO DE DATO			RESTRICCIONES
		relacionEncargadoId	INT						IDENTITY (1,1) PRIMARY KEY,
		relacionEncargado	VARCHAR(45)				NOT NULL
)
GO

INSERT INTO RelacionEncargado VALUES
('Madre'),
('Padre'),
('Abuela'),
('Abuelo'),
('Otro')
GO

SELECT * FROM RelacionEncargado
GO

--Se crea la tabla de Estado
CREATE TABLE Estado(

--		CAMPO				TIPO DE DATO			RESTRICCIONES
		estadoId			INT						IDENTITY (1,1) PRIMARY KEY,
		estado				VARCHAR(45)				NOT NULL
)
GO

INSERT INTO Estado VALUES
('Atendida'),
('Pendiente'),
('Perdida')
GO

SELECT * FROM Estado
GO

--Se crea la tabla de Lugar
CREATE TABLE Lugar(

--		CAMPO				TIPO DE DATO			RESTRICCIONES
		lugarId				INT						IDENTITY (1,1) PRIMARY KEY,
		lugar				VARCHAR(45)				NOT NULL
)
GO

INSERT INTO Lugar VALUES
('Presencial'),
('Virtual')
GO

SELECT * FROM Lugar
GO

---------------------------------------* CAMPOS DENTRO DE LOS CRUD *---------------------------------------

--Se crea la tabla de DatosDelSistema
CREATE TABLE DatosDelSistema(

--		CAMPO					TIPO DE DATO			RESTRICCIONES
		nombreEmpresa			VARCHAR(150)			PRIMARY KEY,
		direccionEmpresa		VARCHAR(300)			NOT NULL,
		correoElectronicoE		VARCHAR(125)			NOT NULL UNIQUE,
		numeroTelefono			VARCHAR(15)				NOT NULL,
		numeroPBX				VARCHAR(15)				NOT NULL,
		fechaCreacionE			DATE					NOT NULL CHECK(fechaCreacionE <= getDate()),
		fotoEmpresa				VARBINARY(MAX)			NOT NULL
)
GO

--------------------------* INSERCI�N EN LA TABLA EMPRESA - CREATE *--------------------------
DECLARE @nombreEmpresa			VARCHAR(150)	= 'ADNE'
DECLARE @direccionEmpresa		VARCHAR(300)	= 'Soyapango'
DECLARE @correoElectronicoE		VARCHAR(125)	= 'adne@gmail.com'
DECLARE @numeroTelefono			VARCHAR(15)		= '2273-6000'
DECLARE @numeroPBX				VARCHAR(15)		= '2257-7777'
DECLARE @fechaCreacionE			DATE			= '2024-08-23'
DECLARE @fotoEmpresa			VARBINARY(MAX)	= 0xFFD8FFE000104A46494600010101004800480000FFDB004300

INSERT INTO DatosDelSistema (nombreEmpresa, direccionEmpresa, correoElectronicoE, numeroTelefono, numeroPBX, fechaCreacionE, fotoEmpresa)
VALUES
(@nombreEmpresa, @direccionEmpresa, @correoElectronicoE, @numeroTelefono, @numeroPBX, @fechaCreacionE, @fotoEmpresa)
GO

--------------------------* ACTUALIZACI�N EN LA TABLA EMPRESA - UPDATE *--------------------------
DECLARE @nombreEmpresa			VARCHAR(150)	= 'ADNE'
DECLARE @direccionEmpresa		VARCHAR(300)	= 'Soyapango'
DECLARE @correoElectronicoE		VARCHAR(125)	= 'adne@gmail.com'
DECLARE @numeroTelefono			VARCHAR(15)		= '2273-6000'
DECLARE @numeroPBX				VARCHAR(15)		= '2257-7777'
DECLARE @fechaCreacionE			DATE			= '2024-08-23'
DECLARE @fotoEmpresa			VARBINARY(MAX)	= 0xFFD8FFE000104A46494600010101004800480000FFDB004300

UPDATE DatosDelSistema SET
nombreEmpresa			= @nombreEmpresa,
direccionEmpresa		= @direccionEmpresa,
correoElectronicoE		= @correoElectronicoE,
numeroTelefono			= @numeroTelefono,
numeroPBX				= @numeroPBX,
fechaCreacionE			= @fechaCreacionE,
fotoEmpresa				= @fotoEmpresa

WHERE
nombreEmpresa = @nombreEmpresa
GO

SELECT * FROM DatosDelSistema
GO

--Se crea la tabla Usuario
CREATE TABLE Usuario(

--		CAMPO				TIPO DE DATO			RESTRICCIONES
		usuarioId			INT						IDENTITY (1,1) PRIMARY KEY,
		nombreUsuario		VARCHAR(30)				COLLATE SQL_Latin1_General_CP1_CS_AS UNIQUE NOT NULL,
		contrase�a			VARCHAR(256)			NOT NULL,
		correoElectronico	VARCHAR(125)			COLLATE SQL_Latin1_General_CP1_CS_AS UNIQUE NOT NULL
)
GO

--------------------------* INSERCI�N EN LA TABLA USUARIO - CREATE *--------------------------
DECLARE @nombreUsuario		VARCHAR(30)			= '@nombreUsuario'
DECLARE @contrase�a			VARCHAR(256)		= '@contrase�a'
DECLARE @correoElectronico	VARCHAR(125)		= '@correoElectronico'

INSERT INTO Usuario (nombreUsuario, contrase�a, correoElectronico)
OUTPUT INSERTED.usuarioId VALUES 
(@nombreUsuario, @contrase�a, @correoElectronico)
GO

--------------------------* ACTUALIZACI�N EN LA TABLA USUARIO CONTRASE�A - UPDATE *--------------------------
DECLARE @nombreUsuario		VARCHAR(30)			= 'sanguchito'
DECLARE @contrase�a			VARCHAR(256)		= '@contrase�a'
DECLARE @correoElectronico	VARCHAR(125)		= '@correoElectronico'
UPDATE Usuario SET
contrase�a			= @contrase�a

WHERE
nombreUsuario = @nombreUsuario OR correoElectronico = @correoElectronico
GO

--------------------------* ACTUALIZACI�N EN LA TABLA USUARIO - UPDATE *--------------------------
DECLARE @usuarioId			INT					= 1
DECLARE @nombreUsuario		VARCHAR(30)			= '@bin'
DECLARE @contrase�a			VARCHAR(256)		= '@contrase�a'
DECLARE @correoElectronico	VARCHAR(125)		= '@correoGmail'

UPDATE Usuario SET
nombreUsuario		= @nombreUsuario,
contrase�a			= @contrase�a,
correoElectronico	= @correoElectronico

WHERE
usuarioId = @usuarioId OR correoElectronico = @correoElectronico
GO

--------------------------* CONSLUTA EN LA TABLA USUARIO - READ *--------------------------
DECLARE @nombreUsuario		VARCHAR(30)			= '@nombreUsuario'
DECLARE @contrase�a			VARCHAR(256)		= '@contrase�a'
SELECT * FROM Usuario WHERE nombreUsuario = @nombreUsuario AND contrase�a = @contrase�a
GO

--------------------------* CONSLUTA EN LA TABLA USUARIO CORREO - READ *--------------------------
DECLARE @nombreUsuario		VARCHAR(30)			= '@nombreUsuario'
DECLARE @correoElectronico	VARCHAR(125)		= '@correoElectronico'
SELECT * FROM Usuario WHERE nombreUsuario = @nombreUsuario OR correoElectronico = @correoElectronico
GO

--------------------------* CONSLUTA EN LA TABLA USUARIO ID - READ *--------------------------
DECLARE @usuarioId			INT					= 1
SELECT * FROM Usuario WHERE usuarioId = @usuarioId
GO

SELECT * FROM Usuario
GO

--------------------------* ELIMINACI�N EN LA TABLA USUARIO - DELETE *--------------------------
--DECLARE @usuarioId			INT				= 1

--DELETE FROM Usuario WHERE usuarioId = @usuarioId
--GO

--Se crea la tabla principal de Paciente
CREATE TABLE Paciente(
 
--		CAMPO				TIPO DE DATO			RESTRICCIONES
		documentoPresentado	VARCHAR(11)				PRIMARY KEY,
		fechaNacimiento		DATE					NOT NULL CHECK(fechaNacimiento <= getDate()),
		nombre				VARCHAR(65)				NOT NULL,
		apellido			VARCHAR(65)				NOT NULL,
		domicilio			VARCHAR(300)			DEFAULT 'No proporcionado',
		nacionalidad		VARCHAR(125)			NOT NULL,
		correoElectronico	VARCHAR(125)			COLLATE SQL_Latin1_General_CP1_CS_AS UNIQUE NOT NULL,
		telefono			VARCHAR(15)				NOT NULL,
		profesion			VARCHAR(100)			NOT NULL,
		edad				INT						NOT NULL,
		composicionFamiliar	VARCHAR(125)			NOT NULL,
		motivo				VARCHAR(300)			NOT NULL,
		antecedente			VARCHAR(300)			NOT NULL,
		descripcionSituacion VARCHAR(300)           NOT NULL,
		aspectosPreocupantes VARCHAR(300)			NOT NULL,
		generoId			INT						FOREIGN KEY REFERENCES Genero(generoId) ON UPDATE CASCADE
)
GO

--------------------------* INSERCI�N EN LA TABLA PACIENTE - CREATE *--------------------------
DECLARE @documentoPresentado	VARCHAR(11)			= '012345678-9'
DECLARE @fechaNacimiento		DATE				= '2007-12-24'
DECLARE @nombre					VARCHAR(65)			= '@Juan Carlos'
DECLARE @apellido				VARCHAR(65)			= '@Rodr�guez Funes'
DECLARE @domicilio				VARCHAR(300)		= '@Sant�sima Trinidad'
DECLARE @nacionalidad			VARCHAR(125)		= '@Salvadore�a'
DECLARE @correoElectronico		VARCHAR(125)		= '@20240158@ricaldone.edu.sv'
DECLARE @telefono				VARCHAR(15)			= '6317-4848'
DECLARE @profesion				VARCHAR(100)		= '@Estudiante'
DECLARE @edad					INT					= 16
DECLARE @composicionFamiliar	VARCHAR(125)		= '@Toda la familia'
DECLARE @motivo					VARCHAR(300)		= '@Fin de una relaci�n'
DECLARE @antecedente			VARCHAR(300)		= '@Ninguno'
DECLARE @descripcionSituacion	VARCHAR(300)        = '@Un caso de cuidado'   
DECLARE @aspectosPreocupantes	VARCHAR(300)		= '@Su actitud'
DECLARE @generoId				INT					= 1
 
INSERT INTO Paciente(documentoPresentado, fechaNacimiento, nombre, apellido, domicilio, nacionalidad, correoElectronico, telefono, profesion, edad, composicionFamiliar, motivo, antecedente, descripcionSituacion, aspectosPreocupantes, generoId)
VALUES
(@documentoPresentado, @fechaNacimiento, @nombre, @apellido, @domicilio, @nacionalidad, @correoElectronico, @telefono, @profesion, @edad, @composicionFamiliar, @motivo, @antecedente, @descripcionSituacion, @aspectosPreocupantes, @generoId)
GO

--------------------------* ACTUALIZACI�N EN LA TABLA PACIENTE - UPDATE *--------------------------
DECLARE @documentoPresentado	VARCHAR(11)			= '012345678-8'
DECLARE @fechaNacimiento		DATE				= '2007-12-24'
DECLARE @nombre					VARCHAR(65)			= '@Camila Alejandra'
DECLARE @apellido				VARCHAR(65)			= '@Claudia Reyes'
DECLARE @domicilio				VARCHAR(300)		= '@----'
DECLARE @nacionalidad			VARCHAR(125)		= '@Salvadore�a'
DECLARE @correoElectronico		VARCHAR(125)		= '@20230559@ricaldone.edu.sv'
DECLARE @telefono				VARCHAR(15)			= '6317-4848'
DECLARE @profesion				VARCHAR(100)		= '@Estudiante'
DECLARE @edad					INT					= 17
DECLARE @composicionFamiliar	VARCHAR(125)		= '@Toda la familia'
DECLARE @motivo					VARCHAR(300)		= '@Fin de una relaci�n'
DECLARE @antecedente			VARCHAR(300)		= '@Ninguno'
DECLARE @descripcionSituacion	VARCHAR(300)        = '@Un caso de cuidado'   
DECLARE @aspectosPreocupantes	VARCHAR(300)		= '@Su actitud'
DECLARE @generoId				INT					= 2
 
UPDATE Paciente SET
documentoPresentado		= @documentoPresentado,
fechaNacimiento			= @fechaNacimiento,
nombre					= @nombre,
apellido				= @apellido,
domicilio				= @domicilio,
nacionalidad			= @nacionalidad,
correoElectronico		= @correoElectronico,
telefono				= @telefono,
profesion				= @profesion,
edad					= @edad,
composicionFamiliar		= @composicionFamiliar,
motivo					= @motivo,
antecedente				= @antecedente,
descripcionSituacion	= @descripcionSituacion,
aspectosPreocupantes	= @aspectosPreocupantes,
generoId				= @generoId
 
WHERE
documentoPresentado = @documentoPresentado
GO

SELECT * FROM Paciente
GO

--Se crea la tabla de Encargado del paciente
CREATE TABLE EncargadoPaciente(
 
--		CAMPO				TIPO DE DATO			RESTRICCIONES
		documentoPresentado	VARCHAR(11)				PRIMARY KEY,
		nombre				VARCHAR(65)				NOT NULL,
		apellido			VARCHAR(65)				NOT NULL,
		fechaNacimiento		DATE					NOT NULL CHECK(fechaNacimiento <= getDate()),
		edad				INT						NOT NULL,
		telefono			VARCHAR(15)				NOT NULL,
		correoElectronico	VARCHAR(125)			COLLATE SQL_Latin1_General_CP1_CS_AS UNIQUE NOT NULL,
		domicilio			VARCHAR(300)			DEFAULT 'No proporcionado',
		documentoPresentadoP VARCHAR(11)			FOREIGN KEY REFERENCES Paciente(documentoPresentado) ON UPDATE CASCADE ON DELETE NO ACTION,
		relacionEncargadoId	INT						FOREIGN KEY REFERENCES RelacionEncargado(relacionEncargadoId) ON UPDATE CASCADE
)
GO

--------------------------* INSERCI�N EN LA TABLA ENCARGADO PACIENTE - CREATE *--------------------------
DECLARE @documentoPresentado	VARCHAR(11)			= '012345678-9'
DECLARE @nombre					VARCHAR(65)			= '@Ricardo Arturo'
DECLARE @apellido				VARCHAR(65)			= '@de Paz N��ez'
DECLARE @fechaNacimiento		DATE				= '2007-12-24'
DECLARE @edad					INT					= 16
DECLARE @telefono				VARCHAR(15)			= '2252-4421'
DECLARE @correoElectronico		VARCHAR(125)		= '@20240012@ricaldone.edu.sv'
DECLARE @domicilio				VARCHAR(300)		= '@Apopa'
DECLARE @documentoPresentadoP	VARCHAR(11)			= '012345678-9'
DECLARE @relacionEncargadoId	INT					= 1
 
INSERT INTO EncargadoPaciente (documentoPresentado, nombre, apellido, fechaNacimiento, edad, telefono, correoElectronico, domicilio, documentoPresentadoP, relacionEncargadoId)
VALUES
(@documentoPresentado, @nombre, @apellido, @fechaNacimiento, @edad, @telefono, @correoElectronico, @domicilio, @documentoPresentadoP, @relacionEncargadoId)
GO

--------------------------* ACTUALIZACI�N EN LA ENCARGADO PACIENTE - UPDATE *--------------------------
DECLARE @documentoPresentado	VARCHAR(11)			= '012345678-9'
DECLARE @nombre					VARCHAR(65)			= '@Ricardo Arturo'
DECLARE @apellido				VARCHAR(65)			= '@de Paz N��ez'
DECLARE @fechaNacimiento		DATE				= '2007-12-24'
DECLARE @edad					INT					= 16
DECLARE @telefono				VARCHAR(15)			= '2252-4421'
DECLARE @correoElectronico		VARCHAR(125)		= '@20240012@ricaldone.edu.sv'
DECLARE @domicilio				VARCHAR(300)		= '@Apopa'
DECLARE @documentoPresentadoP	VARCHAR(11)			= '012345678-9'
DECLARE @relacionEncargadoId	INT					= 1
 
UPDATE EncargadoPaciente SET
nombre					= @nombre,
apellido				= @apellido,
fechaNacimiento			= @fechaNacimiento,
edad					= @edad,
telefono				= @telefono,
correoElectronico		= @correoElectronico,
domicilio				= @domicilio,
documentoPresentadoP	= @documentoPresentadoP,
relacionEncargadoId		= @relacionEncargadoId
 
WHERE
documentoPresentado = @documentoPresentado
GO

SELECT * FROM EncargadoPaciente
GO

--Se crea la tabla de Diagnostico Psicosocial
CREATE TABLE DiagnosticoPsicosocial(

--		CAMPO				TIPO DE DATO			RESTRICCIONES
		expedienteId		INT					    IDENTITY (1,1) PRIMARY KEY,
		estadoAnimo			VARCHAR(500)			NOT NULL,
		estadoConductual	VARCHAR(500)			NOT NULL,
		somatizacion		VARCHAR(500)			NOT NULL,
		vidaInterpersonal	VARCHAR(500)			NOT NULL,
		cognicion			VARCHAR(500)			NOT NULL,
		redSocial			VARCHAR(500)			NOT NULL,
		pauta				VARCHAR(500)			NOT NULL,
		riesgoValorado		VARCHAR(500)			NOT NULL,
		observacion			VARCHAR(500)			NOT NULL,
		aproximacionDiag	VARCHAR(500)			NOT NULL,
		atencionBrindada	VARCHAR(500)			NOT NULL,
		documentoPresentado	VARCHAR(11)				FOREIGN KEY REFERENCES Paciente(documentoPresentado) ON UPDATE CASCADE ON DELETE CASCADE UNIQUE
)
GO

--------------------------* INSERCI�N EN LA TABLA EXPEDIENTE - CREATE *--------------------------
DECLARE @estadoAnimo			VARCHAR(500)		= '@Estable'
DECLARE @estadoConductual		VARCHAR(500)		= '@Alegre'
DECLARE @somatizacion			VARCHAR(500)		= '@Dolor Sentimental'
DECLARE @vidaInterpersonal		VARCHAR(500)		= '@Normal'
DECLARE @cognicion				VARCHAR(500)		= '@Aprendizaje r�pido, buen lenguaje corporal'
DECLARE @redSocial				VARCHAR(500)		= '@Facebook, Instagram'
DECLARE @pauta					VARCHAR(500)		= '@Cursiva'
DECLARE @riesgoValorado			VARCHAR(500)		= '@Impacto en emociones'
DECLARE @observacion			VARCHAR(500)		= '@Paciente en mejora'
DECLARE @aproximacionDiag		VARCHAR(500)		= '@Mejora educativa en el �mbito de psicopedagogo'
DECLARE @atencionBrindada		VARCHAR(500)		= '@Profesional encargado'
DECLARE @documentoPresentado	VARCHAR(11)			= '012345678-9'

INSERT INTO DiagnosticoPsicosocial(estadoAnimo, estadoConductual, somatizacion, vidaInterpersonal, cognicion, redSocial, pauta, riesgoValorado, observacion, aproximacionDiag, atencionBrindada, documentoPresentado)
VALUES 
(@estadoAnimo, @estadoConductual, @somatizacion, @vidaInterpersonal, @cognicion, @redSocial, @pauta, @riesgoValorado, @observacion, @aproximacionDiag, @atencionBrindada, @documentoPresentado)
GO

--------------------------* ACTUALIZACI�N EN LA TABLA EXPEDIENTE - UPDATE *--------------------------
DECLARE @expedienteId			INT					= 1
DECLARE @estadoAnimo			VARCHAR(500)		= '@Estable'
DECLARE @estadoConductual		VARCHAR(500)		= '@Triste'
DECLARE @somatizacion			VARCHAR(500)		= '@Dolor Sentimental'
DECLARE @vidaInterpersonal		VARCHAR(500)		= '@Normal'
DECLARE @cognicion				VARCHAR(500)		= '@Aprendizaje r�pido, buen lenguaje corporal'
DECLARE @redSocial				VARCHAR(500)		= '@Whatsapp'
DECLARE @pauta					VARCHAR(500)		= '@Molde'
DECLARE @riesgoValorado			VARCHAR(500)		= '@Impacto en emociones'
DECLARE @observacion			VARCHAR(500)		= '@Paciente en mejora'
DECLARE @aproximacionDiag		VARCHAR(500)		= '@Mejora educativa en el �mbito de psicopedagogo'
DECLARE @atencionBrindada		VARCHAR(500)		= '@Profesional encargado'
DECLARE @documentoPresentado	VARCHAR(11)			= '012345678-9'

UPDATE DiagnosticoPsicosocial SET
estadoAnimo			= @estadoAnimo,
estadoConductual	= @estadoConductual,
somatizacion		= @somatizacion,
vidaInterpersonal	= @vidaInterpersonal,
cognicion			= @cognicion,
redSocial			= @redSocial,
pauta				= @pauta,
riesgoValorado		= @riesgoValorado,
observacion			= @observacion,
aproximacionDiag	= @aproximacionDiag,
atencionBrindada	= @atencionBrindada,
documentopresentado	= @documentoPresentado

WHERE
expedienteId = @expedienteId
GO

SELECT * FROM DiagnosticoPsicosocial
GO

--Se crea la tabla de Profesional
CREATE TABLE Profesional(

--		CAMPO				TIPO DE DATO			RESTRICCIONES
		DUI					VARCHAR(11)				PRIMARY KEY,
		telefono			VARCHAR(15)				NOT NULL,
		nombre				VARCHAR(65)				NOT NULL,
		apellido			VARCHAR(65)				NOT NULL,
		correoElectronico	VARCHAR(125)			COLLATE SQL_Latin1_General_CP1_CS_AS UNIQUE NOT NULL,
		foto				VARBINARY(MAX)			NOT NULL,
		desempenoId			INT						FOREIGN KEY REFERENCES Desempeno(desempenoId) ON UPDATE CASCADE ON DELETE NO ACTION,
		usuarioId			INT						FOREIGN KEY REFERENCES Usuario(usuarioId) ON UPDATE CASCADE ON DELETE CASCADE
)
GO

--------------------------* INSERCI�N EN LA TABLA PROFESIONAL - CREATE *--------------------------
DECLARE @DUI					VARCHAR(11)		= '012345688-9'
DECLARE @telefono				VARCHAR(15)		= '@telefono'
DECLARE @nombre					VARCHAR(65)		= '@nombre'
DECLARE @apellido				VARCHAR(65)		= '@apellido'
DECLARE @correoElectronico		VARCHAR(125)	= '@correoElectronico'
DECLARE @foto					VARBINARY(MAX)	= 0xFFD8FFE000104A46494600010101004800480000FFDB004300
DECLARE @desempenoId			INT				= 1
DECLARE @usuarioId				INT				= 1

INSERT INTO Profesional(DUI, telefono, nombre, apellido, correoElectronico, foto, desempenoId, usuarioId)
VALUES 
(@DUI, @telefono, @nombre, @apellido, @correoElectronico, @foto, @desempenoId, @usuarioId)
GO

--------------------------* ACTUALIZACI�N EN LA TABLA PROFESIONAL - UPDATE *--------------------------
DECLARE @DUI					VARCHAR(11)		= '012345688-9'
DECLARE @telefono				VARCHAR(15)		= '@telefono'
DECLARE @nombre					VARCHAR(65)		= '@nombre'
DECLARE @apellido				VARCHAR(65)		= '@apellido'
DECLARE @correoElectronico		VARCHAR(125)	= '@correoElectronico'
DECLARE @foto					VARBINARY(MAX)	= 0xFFD8FFE000104A46494600010101004800480000FFDB004300
DECLARE @desempenoId			INT				= 1

UPDATE Profesional SET
telefono			= @telefono,
nombre				= @nombre,
apellido			= @apellido,
correoElectronico	= @correoElectronico,
foto				= @foto,
desempenoId			= @desempenoId

WHERE
DUI = @DUI
GO

SELECT * FROM Profesional
GO

-- Creacion de la tabla intermediaria Nombre Especialidades
CREATE TABLE NombreEspecialidades(

--		CAMPO				TIPO DE DATO			RESTRICCIONES
		especialidadNId		INT						IDENTITY (1,1) PRIMARY KEY,
		DUI					VARCHAR(11)				FOREIGN KEY REFERENCES Profesional(DUI) ON UPDATE CASCADE ON DELETE CASCADE,
		especialidadId		INT						FOREIGN KEY REFERENCES Especialidad(especialidadId) ON UPDATE CASCADE ON DELETE SET NULL,

		-- Creamos la restricci�n validando que, un mismo profesional, no posea la misma especialidad, sin embargo la relaci�n de muchos a muchos se mantiene est�tica
		CONSTRAINT UQ_DUI_Especialidad UNIQUE (DUI, especialidadId)
)
GO

--------------------------* INSERCI�N EN LA TABLA INTERMEDIA NOMBRE ESPECIALIDADES - CREATE *--------------------------
DECLARE @DUI					VARCHAR(11)		= '012345688-9'
DECLARE @especialidadId			INT				= 2

INSERT INTO NombreEspecialidades (DUI, especialidadId)
VALUES 
(@DUI, @especialidadId)
GO

SELECT * FROM NombreEspecialidades --WHERE DUI = '08912798-0'
GO

--------------------------* VISTA EN LA TABLA NOMBRE DE ESPECIALIDADES - READ *--------------------------
CREATE VIEW vistaEspecialidades AS
SELECT N.DUI AS 'DUI', N.especialidadNId, CONCAT (P.nombre,' ', P.apellido) AS 'Nombre del Profesional', E.nombreEspecialidad AS 'Nombre de la Especialidad'
FROM NombreEspecialidades AS N
INNER JOIN Profesional AS P ON N.DUI = P.DUI
INNER JOIN Especialidad AS E ON N.especialidadId = E.especialidadId
GO

SELECT * FROM vistaEspecialidades WHERE DUI = '89723498-2'
GO

--------------------------* VISTA EN LA TABLA PROFESIONAL - READ *--------------------------
CREATE VIEW vistaProfesional AS
SELECT P.DUI, P.telefono, CONCAT(P.nombre, ' ', P.apellido) AS 'Nombre del Profesional', P.foto, D.desempeno, U.nombreUsuario AS 'Nombre del Usuario', STRING_AGG(E.nombreEspecialidad, ', ') AS 'Nombre de la Especialidad'
FROM Profesional AS P
INNER JOIN Desempeno AS D ON P.desempenoId = D.desempenoId
INNER JOIN Usuario AS U ON P.usuarioId = U.usuarioId
INNER JOIN NombreEspecialidades AS N ON P.DUI = N.DUI
LEFT JOIN Especialidad AS E ON N.especialidadId = E.especialidadId

GROUP BY
	P.DUI,
	P.telefono,
	P.nombre,
	P.apellido,
	P.foto,
	D.desempeno,
	U.nombreUsuario
GO

SELECT * FROM vistaProfesional
GO

--------------------------* VISTA EN LA TABLA PROFESIONAL CON PAR�METROS - READ *--------------------------
DECLARE @nombreUsuario		VARCHAR(30)			= 'sanguchito'

SELECT * FROM vistaProfesional WHERE [Nombre del Usuario] = @nombreUsuario
GO

--------------------------* VISTA EN LA TABLA PROFESIONAL DATA GRID - READ *--------------------------
CREATE VIEW vistaProfesionalDGV AS
SELECT P.usuarioId AS 'ID Usuario', P.DUI AS 'DUI', P.telefono AS 'Tel�fono', P.nombre AS 'Nombres', P.apellido AS 'Apellidos', P.correoElectronico AS 'Correo Electr�nico', P.foto AS 'Imagen de la Persona', D.desempeno AS 'Desempe�o', U.nombreUsuario AS 'Nombre del Usuario', STRING_AGG(E.nombreEspecialidad, ', ') AS 'Especialidades'
FROM Profesional AS P
INNER JOIN Desempeno AS D ON P.desempenoId = D.desempenoId
INNER JOIN Usuario AS U ON P.usuarioId = U.usuarioId
INNER JOIN NombreEspecialidades AS N ON P.DUI = N.DUI
LEFT JOIN Especialidad AS E ON N.especialidadId = E.especialidadId

GROUP BY
	P.usuarioId,
	P.DUI,
	P.telefono,
	P.nombre,
	P.apellido,
	P.correoElectronico,
	P.foto,
	D.desempeno,
	U.nombreUsuario
GO

DECLARE @nombres			VARCHAR(65)			= '%J%'
DECLARE @apellidos			VARCHAR(65)			= '%R%'
DECLARE @DUI				VARCHAR(11)			= '%0%'
DECLARE @nombreUsuario		VARCHAR(30)			= '%S%'

SELECT * FROM vistaProfesionalDGV WHERE Nombres LIKE @nombres OR Apellidos LIKE @apellidos OR DUI LIKE @DUI OR [Nombre del Usuario] LIKE @nombreUsuario
GO

SELECT * FROM vistaProfesionalDGV
GO

--------------------------* VISTA EN LA TABLA PROFESIONAL USERCONTROL - READ *--------------------------
CREATE VIEW vistaDataTable AS
SELECT P.DUI, CONCAT(P.nombre, ' ', P.apellido) AS 'Nombre del Profesional', P.correoElectronico, STRING_AGG(E.nombreEspecialidad, ', ') AS 'Especialidades'
FROM Profesional AS P
INNER JOIN NombreEspecialidades AS N ON P.DUI = N.DUI
LEFT JOIN Especialidad AS E ON N.especialidadId = E.especialidadId

GROUP BY
	P.DUI,
	P.nombre,
	P.apellido,
	P.correoElectronico
GO

SELECT * FROM vistaDataTable
GO

-- Creacion de la tabla intermediaria Paciente Y Profesional (profesional encargado solo puede ver sus pacientes)
CREATE TABLE PacienteProfesionalENC(

--		CAMPO				TIPO DE DATO			RESTRICCIONES
		profesionalPAId		INT						IDENTITY (1,1) PRIMARY KEY,
		documentoPresentado	VARCHAR(11)				FOREIGN KEY REFERENCES Paciente(documentoPresentado) ON UPDATE CASCADE ON DELETE NO ACTION,
		DUI					VARCHAR(11)				FOREIGN KEY REFERENCES Profesional(DUI) ON UPDATE CASCADE ON DELETE SET NULL,

		-- Creamos la restricci�n validando que, un mismo profesional, no posea la misma pregunta insertada, sin embargo la relaci�n de muchos a muchos se mantiene est�tica
		CONSTRAINT UQ_DUI_Pacientes UNIQUE (documentoPresentado, DUI)
)
GO

--------------------------* INSERCI�N EN LA TABLA PROFESIONALES ENCARGADOS DE PACIENTES - CREATE *--------------------------
DECLARE @documentoPresentado VARCHAR(11)			= '012345678-9'
DECLARE @DUI				 VARCHAR(11)			= '012345688-9'

INSERT INTO PacienteProfesionalENC (documentoPresentado, DUI)
VALUES 
(@documentoPresentado, @DUI)
GO

--------------------------* ACTUALIZACI�N EN LA TABLA PROFESIONALES ENCARGADOS DE PACIENTES - UPDATE *--------------------------
DECLARE @profesionalPAId	 INT					= 1
DECLARE @documentoPresentado VARCHAR(11)			= '012345678-9'
DECLARE @DUI				 VARCHAR(11)			= '012345688-9'

UPDATE PacienteProfesionalENC SET
documentoPresentado = @documentoPresentado,
DUI					= @DUI

WHERE
profesionalPAId = @profesionalPAId
GO

SELECT * FROM PacienteProfesionalENC
GO

--------------------------* VISTA EN LA TABLA INFORMACION PERSONAL Y PROFESIONAL ASIGNADO - READ *--------------------------
CREATE VIEW vistaPaciente AS
SELECT CONCAT (PA.nombre, ' ', PA.apellido) AS 'Nombre de Paciente', PA.documentoPresentado AS 'Documento del paciente', PR.DUI AS 'DUI'
FROM PacienteProfesionalENC AS ENC
INNER JOIN Paciente AS PA ON ENC.documentoPresentado = PA.documentoPresentado
INNER JOIN Profesional AS PR ON ENC.DUI = PR.DUI
GO

SELECT * FROM vistaPaciente
GO

--Se crea la tabla de Cita
CREATE TABLE Cita(

--		CAMPO				TIPO DE DATO			RESTRICCIONES
		citaId				INT						IDENTITY (1,1) PRIMARY KEY,
		fecha				DATE					NOT NULL CHECK(fecha >= CAST(CURRENT_TIMESTAMP AS DATE)),
		horaInicio			TIME					NOT NULL,
		horaFinal			TIME					NOT NULL,
		estadoId			INT						FOREIGN KEY REFERENCES Estado(estadoId) ON UPDATE CASCADE ON DELETE SET NULL, 
		documentoPresentado	VARCHAR(11)				FOREIGN KEY REFERENCES Paciente(documentoPresentado) ON UPDATE CASCADE ON DELETE NO ACTION,
		DUI					VARCHAR(11)				FOREIGN KEY REFERENCES Profesional(DUI) ON UPDATE CASCADE ON DELETE SET NULL,
		lugarId				INT						FOREIGN KEY REFERENCES Lugar(lugarId) ON UPDATE CASCADE ON DELETE SET NULL
)
GO

--------------------------* INSERCI�N EN LA TABLA CITA - CREATE *--------------------------
DECLARE @fecha					DATE			= '2024-12-21'
DECLARE @horaInicio				TIME			= '13:30:00'
DECLARE @horaFinal				TIME			= '13:30:00'
DECLARE @estadoId				INT				= 1
DECLARE @documentoPresentado	VARCHAR(11)		= '012345678-9'
DECLARE @DUI					VARCHAR(11)		= '012345688-9'
DECLARE @lugarId				INT				= 1

INSERT INTO Cita (fecha, horaInicio, horaFinal, estadoId, documentoPresentado, DUI, lugarId)
 OUTPUT INSERTED.citaId VALUES  
(@fecha, @horaInicio, @horaFinal, @estadoId, @documentoPresentado, @DUI, @lugarId)
GO

--------------------------* ACTUALIZACI�N EN LA TABLA CITA - UPDATE *--------------------------
DECLARE @citaId					INT				= 2
DECLARE @fecha					DATE			= '2024-12-21'
DECLARE @horaInicio				TIME			= '13:30:00'
DECLARE @horaFinal			    TIME			= '13:30:00'
DECLARE @estadoId				INT				= 1
DECLARE @documentoPresentado	VARCHAR(11)		= '012345678-9'
DECLARE @DUI					VARCHAR(11)		= '012345688-9'
DECLARE @lugarId				INT				= 1

UPDATE Cita SET
fecha				= @fecha,
horaInicio			= @horaInicio,
horaFinal			= @horaFinal,
estadoId			= @estadoId,
documentoPresentado	= @documentoPresentado,
DUI					= @DUI,
lugarId				= @lugarId

WHERE
citaId = @citaId
GO

SELECT * FROM Cita
GO

--Se crea la tabla de Consulta
CREATE TABLE Consulta(

--		CAMPO				TIPO DE DATO			RESTRICCIONES
		consultaId			INT						IDENTITY (1,1) PRIMARY KEY,
		descripcion			VARCHAR(500)			NOT NULL,
		citaId				INT						FOREIGN KEY REFERENCES Cita(citaId) ON UPDATE CASCADE ON DELETE CASCADE UNIQUE
)
GO

--------------------------* INSERCI�N EN LA TABLA CONSULTA - CREATE *--------------------------
DECLARE @descripcion		VARCHAR(500)		= '@El paciente se encuentra en buen estado'
DECLARE @citaId				INT					= 1

INSERT INTO Consulta (descripcion, citaId)
VALUES 
(@descripcion, @citaId)
GO

--------------------------* ACTUALIZACI�N EN LA TABLA CONSULTA - UPDATE *--------------------------
DECLARE @consultaId			INT					= 1
DECLARE @descripcion		VARCHAR(500)		= '@El paciente se encuentra en MAL estado'
DECLARE @citaId				INT					= 1

UPDATE Consulta SET
descripcion			= @descripcion,
citaId				= @citaId

WHERE
consultaId = @consultaId
GO

SELECT * FROM Consulta
GO

--------------------------* VISTA EN LA TABLA CITAS - READ *--------------------------
CREATE VIEW vistaCitasAgendadas AS
SELECT C.citaId AS 'ID de la Cita', CU.consultaId AS 'ID de la Consulta', C.documentoPresentado AS 'DUI', C.DUI AS 'ID del Profesional', C.fecha AS 'Fecha de la Cita', C.horaInicio AS 'Hora de Inicio', C.horaFinal AS 'Hora de Finalizaci�n', E.estado AS 'Estado de la Cita', CU.descripcion AS 'Descripci�n', P.nombre AS 'Nombre del Paciente', P.apellido AS 'Apellido del Paciente', PR.nombre AS 'Profesional Encargado', L.lugar AS 'Lugar de la Cita'
FROM Consulta AS CU
INNER JOIN Cita AS C ON CU.citaID = C.citaId
INNER JOIN Estado AS E ON C.estadoId = E.estadoId
INNER JOIN Paciente AS P ON C.documentoPresentado = P.documentoPresentado
INNER JOIN Profesional AS PR ON C.DUI = PR.DUI
INNER JOIN Lugar AS L ON C.lugarId = L.lugarId
GO

SELECT * FROM vistaCitasAgendadas
GO

--------------------------* VISTA EN LA TABLA INFORMACION PERSONAL, EXPEDIENTE Y CITAS PARA EL PDF - READ *--------------------------
CREATE VIEW vistaObtenerInformacionYExpediente AS
--////** Vista para los datos del paciente - Informaci�n Personal **////--
SELECT DP.expedienteId AS 'N� de Expediente', CONCAT (P.nombre, ' ', P.apellido) AS 'Nombre del paciente', P.domicilio AS 'Domicilio', P.nacionalidad AS 'Nacionalidad', P.documentoPresentado AS 'Documento Presentado', P.telefono AS 'Tel�fono',
P.edad AS 'Edad del Paciente', G.genero AS 'G�nero', P.profesion AS 'Profesi�n', P.composicionFamiliar AS 'Composici�n Familiar', P.motivo AS 'Motivo de la Consulta', P.antecedente AS 'Antecedentes Relevantes', P.descripcionSituacion AS 'Descripci�n de la Situaci�n',
P.aspectosPreocupantes AS 'Aspectos preocupantes',

----////** Vista para los datos del paciente - Expediente **////--
DP.estadoAnimo AS 'Afectividad y sintomatolog�a', DP.estadoConductual AS 'Estado Conductual', DP.somatizacion AS 'Somatizaciones', DP.vidaInterpersonal AS 'Vida Interpersonal, Cambios y manejo', DP.cognicion AS 'Cogniciones', DP.redSocial AS 'Redes sociales de apoyo',
DP.pauta AS 'Pautas de afrontamiento', DP.riesgoValorado AS 'Valoraci�n del riesgo', DP.observacion AS 'Observaciones Generales', DP.aproximacionDiag AS 'Aproximaciones Diagn�sticas', DP.atencionBrindada AS 'Atenci�n brindada', C.fecha AS 'Fecha de la Cita',
L.lugar AS 'Lugar de la Cita', CO.descripcion AS 'Descripci�n de la Cita',

----////** Creamos los ID que nos servir�n para declarar restricciones dentro de la Vista **////--
P.documentoPresentado AS 'ID del Paciente', DP.expedienteId AS 'ID del Expediente', C.citaId AS 'ID de la Cita'

FROM DiagnosticoPsicosocial AS DP
INNER JOIN Paciente AS P ON DP.documentoPresentado = P.documentoPresentado
INNER JOIN Genero AS G ON P.generoId = G.generoId
INNER JOIN Cita AS C ON P.documentoPresentado = C.documentoPresentado
INNER JOIN Lugar AS L ON C.lugarId = L.lugarId
LEFT JOIN Consulta AS CO ON C.citaId = CO.citaId
GO

DECLARE @documentoPresentado	VARCHAR(11)			= '012345678-9'
DECLARE @expedienteId			INT					= 1
DECLARE @citaId					INT					= 1

SELECT * FROM vistaObtenerInformacionYExpediente --WHERE DUI = @pacienteId AND [ID del Expediente] = @expedienteId AND [ID de la Cita] = @citaId
GO

DECLARE @documentoPresentado	VARCHAR(11)			= '12312312313'
DECLARE @expedienteId			INT					= 2
DECLARE @citaId					INT					= 10

SELECT * FROM vistaObtenerInformacionYExpediente WHERE [Documento Presentado] = @documentoPresentado AND [ID del Expediente] = @expedienteId AND [ID de la Cita] = @citaId
GO

CREATE VIEW vistaCita AS
SELECT C.citaId , C.documentoPresentado, DP.expedienteId, CONCAT(P.nombre, ' ', P.apellido) AS 'Nombre del Paciente', P.documentoPresentado AS 'Documento de identificaci�n'
FROM Cita AS C
INNER JOIN Paciente AS P ON C.documentoPresentado = P.documentoPresentado
INNER JOIN DiagnosticoPsicosocial AS DP ON P.documentoPresentado = DP.documentoPresentado
GO

SELECT * FROM vistaCita --WHERE [Nombre del Paciente] LIKE '%Eduardo%'
GO

-- Creacion de la tabla intermediaria, preguntas de seguridad
CREATE TABLE PreguntasSeguridad(

--		CAMPO				TIPO DE DATO			RESTRICCIONES
		preguntasId			INT						IDENTITY (1,1) PRIMARY KEY,
		nombrePreguntas		VARCHAR(125)			NOT NULL,
)
GO

--------------------------* INSERCI�N EN LA TABLA PREGUNTAS DE SEGURIDAD - CREATE *--------------------------
INSERT INTO PreguntasSeguridad VALUES 
('�Cu�l fue su primer trabajo?'),
('�Cu�l era su deporte favorito en el instituto?'),
('Cuando era joven, �Qu� quer�a ser de mayor?'),
('�Cu�l es su comida favorita?'),
('�C�mo se llamaba el hospital en el que naci�?'),
('�Cu�l es la persona m�s famosa que ha conocido?'),
('�En qu� ciudad naci� su padre?'),
('�En qu� ciudad naci� su madre?'),
('�Cu�l es el apellido de su profesor favorito del instituto?'),
('�Cu�l era el nombre y apellido de su mejor amigo de la infancia?')
GO

-- Creacion de la tabla intermediaria Nombre Especialidades
CREATE TABLE PreguntasSeguridadProfesionales(

--		CAMPO				TIPO DE DATO			RESTRICCIONES
		preguntasIdN		INT						IDENTITY (1,1) PRIMARY KEY,
		preguntasId			INT						FOREIGN KEY REFERENCES PreguntasSeguridad(preguntasId) ON UPDATE CASCADE ON DELETE SET NULL,
		DUI					VARCHAR(11)				FOREIGN KEY REFERENCES Profesional(DUI) ON UPDATE CASCADE ON DELETE CASCADE,
		respuestaPreguntas	VARCHAR(256)			NOT NULL,

		-- Creamos la restricci�n validando que, un mismo profesional, no posea la misma pregunta insertada, sin embargo la relaci�n de muchos a muchos se mantiene est�tica
		CONSTRAINT UQ_DUI_Preguntas UNIQUE (DUI, preguntasId)
)
GO

--------------------------* INSERCI�N EN LA TABLA PREGUNTAS DE SEGURIDAD - CREATE *--------------------------
DECLARE @preguntasId			INT				= 1
DECLARE @DUI					VARCHAR(11)		= '012345688-9'
DECLARE @respuestaPreguntas		VARCHAR(40)		= 'En la San Alfonso'

INSERT INTO PreguntasSeguridadProfesionales (preguntasId, DUI, respuestaPreguntas)
VALUES 
(@preguntasId, @DUI, @respuestaPreguntas)
GO

SELECT * FROM PreguntasSeguridadProfesionales
GO

--------------------------* VISTA EN LA TABLA PREGUNTAS DE SEGURIDAD NOT IN - READ *--------------------------
DECLARE @preguntasId			INT				= 1

SELECT * FROM PreguntasSeguridadProfesionales WHERE preguntasId NOT IN (@preguntasId)
GO

--------------------------* VISTA EN LA TABLA PREGUNTAS DE SEGURIDAD - READ *--------------------------
CREATE VIEW vistaPreguntasSeguridadP AS
SELECT P.DUI AS 'DUI', U.nombreUsuario AS 'nombreUsuario'
FROM PreguntasSeguridadProfesionales AS PSP
INNER JOIN Profesional AS P ON PSP.DUI = P.DUI
LEFT JOIN Usuario AS U ON P.usuarioId = U.usuarioId
GO

SELECT * FROM vistaPreguntasSeguridadP
GO

DELETE FROM DatosDelSistema
GO

DELETE FROM Profesional
GO

DELETE FROM Usuario
GO

DELETE FROM Cita
GO

DELETE FROM PacienteProfesionalENC
GO

DELETE FROM Paciente
GO

DELETE FROM DiagnosticoPsicosocial
GO

DELETE FROM EncargadoPaciente
GO

DELETE FROM Consulta
GO

DELETE FROM PreguntasSeguridadProfesionales
GO

SELECT TOP 1 * FROM vistaCitasAgendadas WHERE [Fecha de la Cita] >= CONVERT(date, GETDATE()) ORDER BY [Fecha de la Cita] ASC
GO

SELECT *  FROM vistaCitasAgendadas 
WHERE [Fecha de la Cita] = CONVERT(date, GETDATE()) 
ORDER BY [Fecha de la Cita] ASC, [Hora de Inicio] ASC

SELECT * FROM vistaCitaSAgendadas ORDER BY [Fecha de la Cita] ASC
GO

--------------------------* VISTAS EN LA TABLA CITAS, ESTRUCTURA PARA EL CAMPO DE ESTAD�STICAS - READ *--------------------------
SELECT COUNT (citaId) FROM Cita WHERE estadoId = 1	-- Para que se muestre en el dash las 3 opciones de Edwinaso Bv
GO
SELECT COUNT (citaId) FROM Cita WHERE estadoId = 2	-- Para la opci�n de cita perdida 
GO
SELECT COUNT (citaId) FROM Cita WHERE estadoId = 3	-- Para la opci�n de cita pendiente 
GO

DECLARE  @rangoInicio	DATE ='2024-08-30'
DECLARE  @rangoFinal	DATE ='2024-09-10' 

SELECT COUNT (citaId) FROM Cita WHERE fecha BETWEEN  @rangoInicio AND @rangoFinal -- Para que se muestre parametros de 30 dias
GO

DECLARE  @fechaInicio	DATE ='2024-08-30'
DECLARE  @fechaFinal	DATE ='2024-09-10' 

SELECT fecha, COUNT(citaId) FROM Cita WHERE fecha BETWEEN @fechaInicio AND @fechaFinal GROUP BY fecha
GO

CREATE VIEW vistaHistorial AS
SELECT CONCAT(P.nombre, ' ', P.apellido) AS 'NombrePaciente', c.horaInicio AS 'horaInicio', c.horaFinal AS 'horaFinal', P.documentoPresentado AS 'DUI',c.fecha AS 'Fecha de la cita '
FROM Cita AS c
INNER JOIN Paciente AS P ON c.documentoPresentado = P.documentoPresentado
GO

SELECT *  FROM vistaHistorial 
WHERE [Fecha de la cita ] = CONVERT(date, GETDATE()) ORDER BY [Fecha de la cita ] ASC
GO

--------------------------* DROPEO DE TABLAS DENTRO DE SQL SERVER (ES COMO UN DROP DATABASE) *--------------------------
/*
DROP TABLE DatosDelSistema
GO

DROP TABLE NombreEspecialidades
GO

DROP TABLE Especialidad
GO

DROP TABLE PreguntasSeguridadProfesionales
GO

DROP TABLE PreguntasSeguridad
GO

DROP TABLE DiagnosticoPsicosocial
GO

DROP TABLE Consulta
GO

DROP TABLE Cita
GO

DROP TABLE Estado
GO

DROP TABLE EncargadoPaciente
GO

DROP TABLE RelacionEncargado
GO

DROP TABLE PacienteProfesionalENC
GO

DROP TABLE Paciente
GO

DROP TABLE Genero
GO

DROP TABLE Lugar
GO

DROP TABLE Profesional
GO

DROP TABLE Desempeno
GO

DROP TABLE Usuario
GO

DROP VIEW vistaCita
GO

DROP VIEW vistaCitasAgendadas
GO

DROP VIEW vistaDataTable
GO

DROP VIEW vistaEspecialidades
GO

DROP VIEW vistaHistorial
GO

DROP VIEW vistaObtenerInformacionYExpediente
GO

DROP VIEW vistaPaciente
GO

DROP VIEW vistaPreguntasSeguridadP
GO

DROP VIEW vistaProfesional
GO

DROP VIEW vistaProfesionalDGV
GO
*/